package com.example.Farmer;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.Farmer.databinding.ActivityPostBinding;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

public class Activity_Post extends AppCompatActivity {

    private ActivityPostBinding binding;
    private FirebaseAuth mAuth;
    private FirebaseUser currentUser;
    private StorageReference storageReference;

    // Sidebar variables
    private boolean isSidebarOpen = false;
    private View sidebarLayout;
    private static final int IMAGE_SELECTION_CODE = 100;
    private boolean isHomeFragmentVisible = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPostBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        // Initialize Firebase Authentication
        mAuth = FirebaseAuth.getInstance();
        // Initialize Firebase Storage
        storageReference = FirebaseStorage.getInstance().getReference("profile_images");

        // Get the current user
        currentUser = mAuth.getCurrentUser();

        // Display the HomeFragment initially
        replaceFragment(new HomeFragment());

        // Set up the BottomNavigationView listener
        binding.bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.home) {
                replaceFragment(new HomeFragment());
            } else if (itemId == R.id.news) {
                replaceFragment(new NewsFragment());
            } else if (itemId == R.id.addPost) {
                replaceFragment(new AddPostFragment());
            } else if (itemId == R.id.blogs) {
                replaceFragment(new BlogsFragment());
            } else if (itemId == R.id.agriculture) {
                replaceFragment(new AgricultureFragment());
            }
            return true;
        });

        // Load and display the profile picture
        loadProfilePicture();

        // Sidebar setup
        binding.profileImageView.setOnClickListener(v -> toggleSidebar());
    }

    @Override
    public void onBackPressed() {
        if (isSidebarOpen) {
            // If the sidebar is open, close it
            closeSidebar();
        } else {
            // If the sidebar is not open, perform the default back button behavior
            super.onBackPressed();
        }
    }

    private void closeSidebar() {
        // Close sidebar animation
        sidebarLayout.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_out_left));
        binding.getRoot().removeView(sidebarLayout);
        isSidebarOpen = false;
    }

    // Method to replace fragments in the FrameLayout
    public void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_Layout, fragment);
        fragmentTransaction.commit();

        isHomeFragmentVisible = fragment instanceof HomeFragment;
        updateToolbarVisibility();
    }

    // Method to load and display the profile picture from Firebase Storage using Picasso
    private void loadProfilePicture() {
        if (currentUser != null) {
            SharedPreferences preferences = getSharedPreferences("myPreferences", Context.MODE_PRIVATE);
            String user_Id = preferences.getString("user_Id", null);

            // Construct the reference to the profile picture in Firebase Storage
            StorageReference profilePictureRef = storageReference.child(user_Id + ".jpg");

            if (profilePictureRef != null) {
                // Load the profile picture using Picasso
                profilePictureRef.getDownloadUrl().addOnSuccessListener(uri -> {
                    // Log or Toast to check the retrieved image URI
                    Log.d("ProfilePicture", "Image URI: " + uri);

                    // Load the image into the ImageView using Picasso
                    Picasso.get().load(uri).into(binding.profileImageView);
                }).addOnFailureListener(e -> {
                    // Handle failure to load the image
                    e.printStackTrace();
                    Log.e("ProfilePicture", "Failed to load image: " + e.getMessage());
                    Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show();
                });
            } else {
                // Log or Toast if profilePictureRef is null
                Log.e("ProfilePicture", "Profile picture reference is null");
                Toast.makeText(this, "Profile picture reference is null", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void toggleSidebar() {
        if (isSidebarOpen) {
            // Close sidebar animation
            sidebarLayout.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_out_left));
            binding.getRoot().removeView(sidebarLayout);
        } else {
            // Inflate sidebar layout
            sidebarLayout = LayoutInflater.from(this).inflate(R.layout.sidebar_layout, binding.getRoot(), false);
            binding.getRoot().addView(sidebarLayout);

            // Animate sidebar opening
            sidebarLayout.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_in_left));

            // Set up sidebar buttons
            sidebarLayout.findViewById(R.id.changeProfilePictureButton).setOnClickListener(v -> changeProfilePicture());
            sidebarLayout.findViewById(R.id.logoutButton).setOnClickListener(v -> logout());

            // Load the current profile picture into the sidebarProfileImage
            loadProfilePictureIntoSidebar();
        }
        isSidebarOpen = !isSidebarOpen;
    }

    private void changeProfilePicture() {
        // Start image selection intent
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, IMAGE_SELECTION_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == IMAGE_SELECTION_CODE && resultCode == RESULT_OK) {
            // Process selected image and upload to Firebase Storage
            Uri imageUri = data.getData();

            // Update profile pictures in toolbar and sidebar
            Picasso.get().load(imageUri).into(binding.profileImageView);
            ImageView sidebarProfileImage = sidebarLayout.findViewById(R.id.sidebarProfileImage);
            Picasso.get().load(imageUri).into(sidebarProfileImage);

            // Show toast message
            Toast.makeText(this, "Profile image updated", Toast.LENGTH_SHORT).show();

            // Upload the new image to Firebase Storage
            uploadProfilePicture(imageUri);
        }
    }

    private void uploadProfilePicture(Uri imageUri) {
        if (currentUser != null) {
            SharedPreferences preferences = getSharedPreferences("myPreferences", Context.MODE_PRIVATE);
            String user_Id = preferences.getString("user_Id", null);

            // Construct the reference to the profile picture in Firebase Storage
            StorageReference profilePictureRef = storageReference.child(user_Id + ".jpg");

            // Upload the new image to Firebase Storage
            profilePictureRef.putFile(imageUri)
                    .addOnSuccessListener(taskSnapshot -> {
                        // Get the download URL
                        profilePictureRef.getDownloadUrl().addOnSuccessListener(uri -> {
                            String downloadUrl = uri.toString();

                            // Update the imageUrl field in Firestore
                            updateImageUrlInFirestore(user_Id, downloadUrl);

                            // Image uploaded successfully
                            Log.d("ProfilePicture", "Image uploaded to Firebase Storage");
                            Toast.makeText(this, "Image uploaded to Firebase Storage", Toast.LENGTH_SHORT).show();
                        }).addOnFailureListener(e -> {
                            // Handle failure to get download URL
                            e.printStackTrace();
                            Log.e("ProfilePicture", "Failed to get download URL: " + e.getMessage());
                            Toast.makeText(this, "Failed to get download URL", Toast.LENGTH_SHORT).show();
                        });
                    })
                    .addOnFailureListener(e -> {
                        // Handle failure to upload image
                        e.printStackTrace();
                        Log.e("ProfilePicture", "Failed to upload image to Firebase Storage: " + e.getMessage());
                        Toast.makeText(this, "Failed to upload image to Firebase Storage", Toast.LENGTH_SHORT).show();
                    });
        }
    }

    private void updateImageUrlInFirestore(String userId, String imageUrl) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        CollectionReference usersCollection = db.collection("Users");

        // Query for the specific user by userName

        usersCollection.whereEqualTo("username", userId).get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    // Check if the query returned any documents
                    if (!queryDocumentSnapshots.isEmpty()) {
                        // Update the imageUrl field for the first document (assuming userName is unique)
                        DocumentSnapshot documentSnapshot = queryDocumentSnapshots.getDocuments().get(0);

                        // Update the "imageUrl" field in the Firestore document
                        documentSnapshot.getReference().update("imageUrl", imageUrl)
                                .addOnSuccessListener(aVoid -> {
                                    Log.d("ProfilePicture", "ImageUrl updated in Firestore");
                                })
                                .addOnFailureListener(e -> {
                                    Log.e("ProfilePicture", "Failed to update imageUrl in Firestore: " + e.getMessage());
                                });
                    } else {
                        Log.e("ProfilePicture", "No user found with userName: " + userId);
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e("ProfilePicture", "Error querying Firestore: " + e);
                });
    }


    private void loadProfilePictureIntoSidebar() {
        if (currentUser != null) {
            SharedPreferences preferences = getSharedPreferences("myPreferences", Context.MODE_PRIVATE);
            String user_Id = preferences.getString("user_Id", null);

            // Construct the reference to the profile picture in Firebase Storage
            StorageReference profilePictureRef = storageReference.child(user_Id + ".jpg");

            if (profilePictureRef != null) {
                // Load the profile picture using Picasso
                profilePictureRef.getDownloadUrl().addOnSuccessListener(uri -> {
                    ImageView sidebarProfileImage = sidebarLayout.findViewById(R.id.sidebarProfileImage);
                    // Load the image into the ImageView using Picasso
                    Picasso.get().load(uri).into(sidebarProfileImage);
                }).addOnFailureListener(e -> {
                    // Handle failure to load the image
                    e.printStackTrace();
                    Log.e("ProfilePicture", "Failed to load image: " + e.getMessage());
                });
            } else {
                // Log or Toast if profilePictureRef is null
                Log.e("ProfilePicture", "Profile picture reference is null");
            }
        }
    }

    private void logout() {
        mAuth.signOut();

        if(mAuth != null) {
            // Clear user data
            // Redirect to login screen
            Intent intent = new Intent(this, LoginActivity.class); // Replace with your login activity
            startActivity(intent);
            finish();
        }
        else{
            Toast.makeText(this, "mAuth null", Toast.LENGTH_SHORT).show();
        }
    }



    private void updateToolbarVisibility() {
        binding.toolbar.setVisibility(isHomeFragmentVisible ? View.VISIBLE : View.GONE);
    }
}
