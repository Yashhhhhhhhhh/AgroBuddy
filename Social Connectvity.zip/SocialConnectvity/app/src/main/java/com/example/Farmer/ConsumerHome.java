package com.example.Farmer;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ConsumerHome extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consumer_home);

        // Initialize UI elements
        TextView welcomeTextView = findViewById(R.id.welcomeTextView);

        // Get the current user's display name (replace this with your actual user data retrieval logic)
        String displayName = "Consumer"; // Replace with actual display name retrieval

        // Display the welcome message
        welcomeTextView.setText("Welcome to Consumer Page, " + displayName + "!");
    }
}
