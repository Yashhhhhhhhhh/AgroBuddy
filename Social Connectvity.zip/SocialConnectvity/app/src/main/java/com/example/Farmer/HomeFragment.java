package com.example.Farmer;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment implements OnLikeClickListener, OnCommentClickListener, OnShareClickListener {

    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference postsCollection = db.collection("posts");
    private CollectionReference usersCollection = db.collection("Users");

    private RecyclerView recyclerView;
    private List<Post> itemList;
    private Post_Adapter myAdapter;

    private SwipeRefreshLayout swipeRefreshLayout;

    private String user_Id;
    private boolean isInitialDataLoaded = false;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        SharedPreferences preferences = requireActivity().getSharedPreferences("myPreferences", Context.MODE_PRIVATE);
        user_Id = preferences.getString("user_Id", null);

        recyclerView = view.findViewById(R.id.recyclerView);
        itemList = new ArrayList<>();
        swipeRefreshLayout = view.findViewById(R.id.swipeRefreshLayout);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(linearLayoutManager);

        myAdapter = new Post_Adapter(itemList, this, this, this, user_Id);
        recyclerView.setAdapter(myAdapter);

        SearchView searchView = getActivity().findViewById(R.id.searchView);
        if (searchView != null) {
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    // Handle search submission
                    if (!query.isEmpty()) {
                        // Perform the search only when the user submits the query
                        searchPosts(query);
                    } else {
                        // If the search query is empty, you may want to show all posts or the previous data
                        fetchData();
                    }
                    return true;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    // Handle search text change (optional)
                    // You can leave this method empty or use it for real-time filtering while the user types
                    return true;
                }
            });
        } else {
            Toast.makeText(getContext(), "Search view is null", Toast.LENGTH_SHORT).show();
        }

        swipeRefreshLayout.setOnRefreshListener(() -> {
            if (isNetworkConnected()) {
                fetchData();
            } else {
                Toast.makeText(getContext(), "No Internet Connection", Toast.LENGTH_SHORT).show();
            }
            swipeRefreshLayout.setRefreshing(false);
        });

        if (!isInitialDataLoaded && isNetworkConnected()) {
            fetchData();
        } else if (!isNetworkConnected()) {
            Toast.makeText(getContext(), "No Internet Connection", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isNetworkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) requireContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    private void fetchData() {
        List<Task<DocumentSnapshot>> tasks = new ArrayList<>();

        postsCollection.get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    List<Post> items = new ArrayList<>();
                    for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        Post item = document.toObject(Post.class);
                        item.setImageUrl(document.getString("imageUrl"));

                        String postUserId = item.getUsername();
                        Task<DocumentSnapshot> userTask = usersCollection.document(postUserId).get().addOnSuccessListener(documentSnapshot -> {
                            String profilePhotoUrl = documentSnapshot.getString("imageUrl");
                            item.setProfilePhotoUrl(profilePhotoUrl);
                        });

                        tasks.add(userTask);

                        if (!itemList.contains(item)) {
                            items.add(item);
                        }
                    }

                    Tasks.whenAllSuccess(tasks).addOnSuccessListener(results -> {
                        itemList.clear();
                        itemList.addAll(items);
                        myAdapter.notifyDataSetChanged();

                        isInitialDataLoaded = true;
                    });
                })
                .addOnFailureListener(e -> {
                    Log.e("FirestoreError", "Fetch failed.", e);
                    Toast.makeText(getContext(), "Failed to fetch data", Toast.LENGTH_SHORT).show();
                });
    }

    private void searchPosts(String keyword) {


        // Clear existing items
        itemList.clear();

        List<Task<DocumentSnapshot>> tasks = new ArrayList<>();

        // Construct a Firestore query to search for posts based on keywords in the "keywords" field
        postsCollection.whereEqualTo("username", keyword.toLowerCase())
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        Post item = document.toObject(Post.class);
                        item.setImageUrl(document.getString("imageUrl"));
                        String postUserId = item.getUsername();

                        Task<DocumentSnapshot> userTask = usersCollection.document(postUserId).get().addOnSuccessListener(documentSnapshot -> {
                            String profilePhotoUrl = documentSnapshot.getString("imageUrl");
                            item.setProfilePhotoUrl(profilePhotoUrl);
                        });

                        tasks.add(userTask);

                        // Add the post to the list
                        itemList.add(item);
                    }

                    // Update the RecyclerView with the search results
                    Tasks.whenAllSuccess(tasks).addOnSuccessListener(results -> {
                        // Update UI with the fetched data
                        myAdapter.notifyDataSetChanged();

                    });
                })
                .addOnFailureListener(e -> {
                    Log.e("FirestoreError", "Search failed.", e);
                    Toast.makeText(getContext(), "Firestore error", Toast.LENGTH_SHORT).show();
                });
    }

    public void onLikeClick(int position) {

        SharedPreferences preferences = requireActivity().getSharedPreferences("myPreferences", Context.MODE_PRIVATE);
        String user_Id = preferences.getString("user_Id", null);
        if (user_Id != null) {
            Post clickedPost = itemList.get(position);

            // Check if the user has already liked the post
            if (clickedPost.getLikes() == null || !clickedPost.getLikes().contains(user_Id)) {
                // If not liked, add the user ID to the likes list
                clickedPost.addLike(user_Id);
                clickedPost.setNoOfLikes(clickedPost.getNoOfLikes() + 1);
            } else {
                // If already liked, remove the user ID from the likes list
                clickedPost.removeLike(user_Id);
                clickedPost.setNoOfLikes(clickedPost.getNoOfLikes() - 1);
            }


            postsCollection.document(clickedPost.getPostId())
                    .update("likes", clickedPost.getLikes(), "noOfLikes", clickedPost.getNoOfLikes())
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            myAdapter.notifyItemChanged(position, "likes");
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.e("FirestoreError", "Update failed.", e);
                        }
                    });
//
        } else {
            // User is not logged in, handle accordingly
            Toast.makeText(getContext(), "User not logged in", Toast.LENGTH_SHORT).show();
        }


    }


    public void onCommentClick(int position) {

        Post clickedPost = itemList.get(position);

        Bundle bundle = new Bundle();
        bundle.putString("postId", clickedPost.getPostId());

        fragment_comment commentFragment = new fragment_comment();
        commentFragment.setArguments(bundle);

        commentFragment.show(getChildFragmentManager(), commentFragment.getTag());

    }


    public void onShareClick(int position) {
        Toast.makeText(getContext(), "Work in progress....", Toast.LENGTH_SHORT).show();
    }
}