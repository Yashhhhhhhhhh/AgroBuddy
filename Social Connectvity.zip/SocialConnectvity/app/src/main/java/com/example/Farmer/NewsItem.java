// NewsItem.java
package com.example.Farmer;

public class NewsItem {
    private String newsText;
    private String link;

    public NewsItem(String newsText, String link) {
        this.newsText = newsText;
        this.link = link;
    }

    public void setNewsText(String newsText) {
        this.newsText = newsText;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getNewsText() {
        return newsText;
    }

    public String getLink() {
        return link;
    }
}
