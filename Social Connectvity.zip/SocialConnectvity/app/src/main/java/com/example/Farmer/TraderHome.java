package com.example.Farmer;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class TraderHome extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trader_home);

        // Initialize UI elements
        TextView welcomeTextView = findViewById(R.id.welcomeTextView);

        // Get the current user's display name (replace this with your actual user data retrieval logic)
        String displayName = "Trader"; // Replace with actual display name retrieval

        // Display the welcome message
        welcomeTextView.setText("Welcome to Trader Page, " + displayName + "!");
    }
}
